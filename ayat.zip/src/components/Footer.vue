<template>
    <footer>
        library <b><a href="https://alquran.cloud/api" target="_blank">alquran.cloud</a></b> ❤<br/>
        Developed by <b><a href="http://harran.me" target="_blank">
        Harran El-Marri </a></b> <br/>
        github <b-icon-github/> <b><a href="https://github.com/harran55/vue-quran" target="_blank">vue-quran</a></b>
        <br/>
        v 2021.7
    </footer>
</template>

<style>
footer, footer b, footer b a {
    direction: ltr;
    font-family: monospace;
    font-size: 12px;
    margin: 35px 0;
}

.dark footer {
    color: white;
}

.dark footer b a {
    color: #41b883;
}
</style>